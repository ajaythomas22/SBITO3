package animal.test;

import animal.exceptions.DogAgeExceededException;
import animal.exceptions.DogAgeNegativeException;
import animal.exceptions.DogNameException;
import animal.mammal.Dogs;

public class TestException {

	public static void main(String[] args) {
		
		
		try {
				Dogs d1 = new Dogs(10, "Blacky");
				System.out.println("Doggie "+d1);
			}
		catch (DogAgeExceededException e) {
			e.printStackTrace();
		}
		catch (DogNameException e) {
			e.printStackTrace();
		}
		catch (DogAgeNegativeException e) {
			e.printStackTrace();
		}
		/*
		 * finally { System.out.println("Reached Final Block"); }
		 */
		try {	
				Dogs d2 = new Dogs(15, "Blacky");
				System.out.println("Doggie "+d2);
		}
		catch (DogAgeExceededException e) {
			e.printStackTrace();
		}
		catch (DogNameException e) {
			e.printStackTrace();
		}
		catch (DogAgeNegativeException e) {
			e.printStackTrace();
		}
		/*
		 * finally { System.out.println("Reached Final Block"); }
		 */
		try {	
				Dogs d3 = new Dogs(10, "Blacky");
				System.out.println("Doggie "+d3);
			}
		catch (DogAgeExceededException e) {
			e.printStackTrace();
		}
		catch (DogNameException e) {
			e.printStackTrace();
		}
		catch (DogAgeNegativeException e) {
			e.printStackTrace();
		}
		/*
		 * finally { System.out.println("Reached Final Block"); }
		 */	
		
	}
}
