package animal.mammal;

import animal.exceptions.DogAgeExceededException;
import animal.exceptions.DogAgeNegativeException;
import animal.exceptions.DogNameException;

public class Dogs {

	private int age;
	private String name;
	
	public Dogs(int age, String name) throws DogAgeExceededException, DogNameException, DogAgeNegativeException   {
		
		if (age > 14) {
			throw new DogAgeExceededException("Dog's age cannot be greater than 14");
		}
		else {
			this.age=age;
		}
		
		if (isStringOnlyAlphabet(name)) {
			
			this.name= name;
		}
		else {
			throw new DogNameException("Dog's name is Invalid");
		}
	}
	
	@Override
	public String toString() {
		return "Dog [age=" + age + ", name=" + name + "]";
	}
	
	private static boolean isStringOnlyAlphabet(String str) 
	{
	    return ((!str.equals(""))
	            && (str != null)
	            && (str.matches("^[a-zA-Z]*$")));
	}
}
