package animal.exceptions;

public class DogNameException extends Exception {

	public DogNameException (String str) {
		super(str);
	}
}
