package animal.exceptions;

public class DogAgeNegativeException extends Exception {

	public DogAgeNegativeException (String str) {
		super(str);
	}
}
