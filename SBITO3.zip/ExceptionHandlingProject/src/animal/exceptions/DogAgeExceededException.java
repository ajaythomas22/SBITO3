package animal.exceptions;

public class DogAgeExceededException extends Exception {
	
	public DogAgeExceededException (String str) {
		super(str);
	}

}
