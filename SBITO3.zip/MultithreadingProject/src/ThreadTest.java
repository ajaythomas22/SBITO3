import java.util.Iterator;

public class ThreadTest {

	public static void main(String[] args) {
		Car c = new Car();
		
	}
}

class Car extends Thread {
	
	public void run() {
		for(int i =1; i < 50; i++) {
			System.out.println("CAR IS RUNNING");
			try {
				Thread.sleep(50);
			}
			catch (InterruptedException  e) {
				e.printStackTrace();
			}
		}
	}
	
}
class Train extends Thread {
	public void run() {
		for (int i = 1; i < 100; i++) {
			System.out.println("\tTRAIN IS RUNNING"+i);
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
