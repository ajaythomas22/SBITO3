import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.Frame;

import javax.swing.JFrame;

public class FrameTest {

	public static void main(String[] args) {
		MyCarFrame mcf = new MyCarFrame("CAR");
		MyTrainFrame mtf = new MyTrainFrame("TRAIN");
		MyFlightFrame mff = new MyFlightFrame("FLIGHT");

		Thread t1 = new Thread(mcf);
		Thread t2 = new Thread(mtf);
		Thread t3 = new Thread(mff);

		mcf.setVisible(true);
		mtf.setVisible(true);
		mff.setVisible(true);

		t1.start();
		t2.start();
		t3.start();

	}
}

class MyCarFrame extends JFrame implements java.lang.Runnable {

	TextField t = new TextField(50);

	MyCarFrame(String title) {
		super(title);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void run() {

		for (int i = 1; i <= 200; i++) {
			try {
			
				t.setText("" + i);
				setSize(400, 200);
				setLocation(100, 100);
				setLayout(new FlowLayout());
				add(t);
				setVisible(true);
				setBackground(Color.GREEN);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

class MyTrainFrame extends JFrame implements java.lang.Runnable {

	TextField t = new TextField(50);

	MyTrainFrame(String title) {
		super(title);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void run() {

		for (int i = 1; i <= 200; i++) {
			
			try {
				t.setText("" + i);
				setSize(400, 200);
				setLocation(350, 350);
				setLayout(new FlowLayout());
				add(t);
				setVisible(true);
				setBackground(Color.RED);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

class MyFlightFrame extends JFrame implements java.lang.Runnable {

	TextField t = new TextField(50);

	MyFlightFrame(String title) {
		super(title);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void run() {

		for (int i = 1; i <= 200; i++) {
			try {
				t.setText("" + i);
				setSize(400, 200);
				setLocation(500, 500);
				setLayout(new FlowLayout());
				add(t);
				setForeground(Color.green);
				setVisible(true);
				setBackground(Color.BLUE);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}