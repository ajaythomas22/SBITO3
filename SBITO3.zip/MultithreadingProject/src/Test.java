public class Test {

	public static void main(String[] args) {
		Car2 c = new Car2();
		c.start();
		System.out.println("-----------");
		Person p = new Person();
		Vehicle v = new Vehicle(p);
		v.start();
		
	}
}
interface Runnable {
	void run();
}
class Vehicle implements Runnable {

	Runnable r;
	
	public Vehicle() {
		System.out.println("Vehicle()");
	}
	
	@Override
	public void run() {
		System.out.println("Vehicle is running.");
	}	
	Vehicle(Runnable r) {
		System.out.println("Vehicle(Runnable)");
		this.r= r;
	}
	public void start() {
		System.out.println("Starting Vehicle");
		if(r==null) {
			run();
		}
		else
			r.run();
	}
}

class Car2 extends Vehicle {
	
	public void run() {
		System.out.println("Car is running");
	}
}
class Human {
	void think() {}
}
class Person extends Human implements Runnable {
	void talk() { }
	public void run() {
		System.out.println("Person is running");
	}
}