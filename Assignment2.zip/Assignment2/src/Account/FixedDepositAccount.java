package Account;

public class FixedDepositAccount extends SavingsAccount {

	private int tenure;

	FixedDepositAccount(int x, String y, double z, double r, int t) {
		super(x, y, x, r);
		System.out.println("FixedDepositAccount(int,String,double,double,int)--- Contructor invoked");
		if (t < 0) {
			throw new RuntimeException("The tenure cannot be negative...Terminating");
		} else
			tenure = t;
	}

	void printAccount() {
		super.printAccount();
		System.out.println("Account Tenure: " + tenure);
	}

	double maturityAmount() {
		double a = Math.pow((1 + rateOfInterest / 100), tenure);
		double p = accountBalance * a;
		return p;
	}
}
