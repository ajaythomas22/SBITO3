package Account;

public class BankAccount {
	private int accountNumber;
	private String accountHolderName;
	protected double accountBalance;

	BankAccount(int a, String b, double c) {

		System.out.println("ParentAccount(int,String,double)...Constructor invoked....");

		if (a < 0)

		{
			throw new RuntimeException("Account number cannot be in negative...terminating..");
		}

		else
			accountNumber = a;

		if (b == null) {

			throw new RuntimeException("Account holder name cannot be null...terminating..");
		} else
			accountHolderName = b;

		if (c < 0) {
			throw new RuntimeException("Account Balance cannot be in negative...terminating..");
		}

		else
			accountBalance = c;
	}

	void printAccount() {
		System.out.println("The Account Number: " + accountNumber);
		System.out.println("The Account Holder Name " + accountHolderName);
		System.out.println("The Account Balance " + accountBalance);
	}

	double withdraw(double amountToWithdraw) {
		if (amountToWithdraw > accountBalance) {
			throw new RuntimeException("Insufficient funds....");
		}
		System.out.println("Withdraw in progresss..." + amountToWithdraw);
		accountBalance = accountBalance - amountToWithdraw;
		System.out.println("Withdraw is done...");
		return accountBalance;
	}

	double deposit(double amountToDeposit) {
		if (amountToDeposit > 50000) {
			throw new RuntimeException("Please provide the PAN OR Form60");
		}
		System.out.println("Deposit in progresss..." + amountToDeposit);
		accountBalance = accountBalance + amountToDeposit;
		System.out.println("Deposit is done...");
		return accountBalance;
	}

	double getBalance() {
		return accountBalance;
	}
}
