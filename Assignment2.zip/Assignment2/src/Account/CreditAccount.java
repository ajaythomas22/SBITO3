package Account;

public class CreditAccount extends BankAccount {

	int creditLimit;

	CreditAccount(int x, String y, double z, int c) {

		super(x, y, z);
		System.out.println("CreditAccount(int,String,double,int)...Constructor invoked");
		if (c < 0) {
			throw new RuntimeException("The credit Limit should not be Negative...Terminating");
		} else
			creditLimit = c;
	}

	void printAccount() {
		super.printAccount();
		System.out.println("The Credit Limit is " + creditLimit);
	}

	void calculateCreditBalance() {
		if (creditLimit < accountBalance) {
			System.out.println("The Account is Overdrawn");
		} else
			System.out.println("The Amount " + (creditLimit - accountBalance) + " is available for withdrawal");

	}
}
