package Account;

public class CurrentAccount extends BankAccount {
	String ownerType;

	CurrentAccount(int x, String y, double z, String p) {

		super(x, y, z);
		System.out.println("CurrentAccount(int,String,double,String)...Constructor invoked");
		ownerType = p;
	}

	void printAccount() {
		super.printAccount();
		System.out.println("Owner Type of Current Account: " + ownerType);
	}

	double withdraw(double withdrawAmount) {
		super.withdraw(withdrawAmount);
		return withdrawAmount;
	}

	double deposit(double depositAmount) {
		super.deposit(depositAmount);
		return depositAmount;
	}

	double getBalanceCur() {
		return accountBalance;
	}
}
