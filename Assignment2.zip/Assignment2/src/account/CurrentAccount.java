package account;

import exceptions.AccountNameInvalidException;
import exceptions.AccountNumberNegativeException;
import exceptions.BalanceNegativeExceptions;
import exceptions.InsufficientFundException;
import exceptions.PANException;

public class CurrentAccount extends BankAccount {
	String ownerType;

	CurrentAccount(int x, String y, double z, String p) throws AccountNumberNegativeException, BalanceNegativeExceptions, AccountNameInvalidException {

		super(x, y, z);
		System.out.println("CurrentAccount(int,String,double,String)...Constructor invoked");
		ownerType = p;
	}

	void printAccount() {
		super.printAccount();
		System.out.println("Owner Type of Current Account: " + ownerType);
	}

	double withdraw(double withdrawAmount) throws InsufficientFundException {
		super.withdraw(withdrawAmount);
		return withdrawAmount;
	}

	double deposit(double depositAmount) throws PANException {
		super.deposit(depositAmount);
		return depositAmount;
	}

	double getBalanceCur() {
		return accountBalance;
	}
}
