package account;

import exceptions.AccountNameInvalidException;
import exceptions.AccountNumberNegativeException;
import exceptions.BalanceNegativeExceptions;
import exceptions.InsufficientFundException;
import exceptions.PANException;

public class BankAccount extends Thread {
	private int accountNumber;
	private String accountHolderName;
	protected double accountBalance;
	double withdrawAmount;
	double depositAmount;

	BankAccount(int a, String b, double c) throws AccountNumberNegativeException, BalanceNegativeExceptions, AccountNameInvalidException {

		//System.out.println("ParentAccount(int,String,double)...Constructor invoked....");

		if (a < 0)

		{
			throw new AccountNumberNegativeException("Account number cannot be in Negative..Terminating!!!");
		}

		else
			accountNumber = a;

		if (b == null) {

			throw new AccountNameInvalidException("Account Holder Name cannot be Null..Terminating!!!");
		} else
			accountHolderName = b;

		if (c < 0) {
			throw new BalanceNegativeExceptions("Account Balance cannot be in Negative..Terminating!!!");
		}

		else
			accountBalance = c;
	}
	
	BankAccount(int a, String b, double c, double w, double d) throws AccountNumberNegativeException, BalanceNegativeExceptions, AccountNameInvalidException {

		//System.out.println("ParentAccount(int,String,double)...Constructor invoked....");

		if (a < 0)

		{
			throw new AccountNumberNegativeException("Account number cannot be in Negative..Terminating!!!");
		}

		else
			accountNumber = a;

		if (b == null) {

			throw new AccountNameInvalidException("Account Holder Name cannot be Null..Terminating!!!");
		} else
			accountHolderName = b;

		if (c < 0) {
			throw new BalanceNegativeExceptions("Account Balance cannot be in Negative..Terminating!!!");
		}

		else
			accountBalance = c;
			withdrawAmount = w;
			depositAmount  = d;
			
	}


	void printAccount() {
		System.out.println("------------------------------");
		System.out.println("The Account Number: " + accountNumber);
		System.out.println("The Account Holder Name " + accountHolderName);
		System.out.println("The Account Balance " + accountBalance);
		System.out.println("------------------------------");
	}

	double withdraw(double amountToWithdraw) throws InsufficientFundException {
		if (amountToWithdraw > accountBalance) {
			throw new InsufficientFundException("Insufficient Funds!!!");
		}
		System.out.println("Withdraw in progresss..." + amountToWithdraw);
		accountBalance = accountBalance - amountToWithdraw;
		System.out.println("Withdraw is done...");
		return accountBalance;
	}

	double deposit(double amountToDeposit) throws PANException {
		if (amountToDeposit > 50000) {
			throw new PANException("Please provide the PAN OR Form60!!!");
		}
		System.out.println("Deposit in progresss..." + amountToDeposit);
		accountBalance = accountBalance + amountToDeposit;
		System.out.println("Deposit is done...");
		return accountBalance;
	}

	double getBalance() {
		return accountBalance;
	}

	@Override
	public void run() {
		try {
			withdraw(withdrawAmount);
		} catch (InsufficientFundException e) {
			e.printStackTrace();
		}
		try {
			deposit(depositAmount);
		} catch (PANException e) {
			e.printStackTrace();
		}	
	}
}
