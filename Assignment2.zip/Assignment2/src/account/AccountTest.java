package account;

import java.util.Scanner;

import exceptions.AccountNameInvalidException;
import exceptions.AccountNumberNegativeException;
import exceptions.BalanceNegativeExceptions;
import exceptions.InsufficientFundException;
import exceptions.PANException;

public class AccountTest extends Thread {

	public static void main(String[] args) {

		int accountNumber=101;
		String accountHolderName= "Anand";
		double accountBalance1 = 50000;
		double withdrawAmount1;
		double depositAmount1;
		
		//int accountNumber2;
		//String accountHolderName2;
		double accountBalance2 = 60000;
		double withdrawAmount2;
		double depositAmount2;

		double newWithdrawAmount1 = 0;
		double newDepositAmount1 = 0;
		double newWithdrawAmount2 = 0;
		double newDepositAmount2 = 0;

		int x = 0;
		Scanner scan = new Scanner(System.in);

//				do {
		System.out.println("\tM Y    B A N K");
		System.out.println("-------------------------");
		System.out.println("Enter your Account Number: ");
		Scanner scanAcc = new Scanner(System.in);
		accountNumber = scanAcc.nextInt();

//				System.out.println("Enter the Current Balance: ");
//				Scanner scanBal = new Scanner(System.in);
//				accountBalance = scanAcc.nextInt();

		System.out.println("Enter the accountHolderName: ");
		Scanner scanName = new Scanner(System.in);
		accountHolderName = scanAcc.next();

//				System.out.println("Press 5 to Exit or 1 to Continue");
//				System.out.println("---------------------------------");
//				x = scan.nextInt();
//				}while (x!=5 && x==1);

		try {
			BankAccount bankObj1 = new BankAccount(accountNumber, accountHolderName, accountBalance1);
			bankObj1.printAccount();
			
			BankAccount bankObj2 = new BankAccount(accountNumber, accountHolderName, accountBalance2);
			bankObj2.printAccount();
//			do {
//				System.out.println("Enter the Amount to be Withdrawn: ");
//				Scanner scanWith = new Scanner(System.in);
//				withdrawAmount = scanWith.nextDouble();
//				newWithdrawAmount = newWithdrawAmount + withdrawAmount;
//
//				System.out.println("Enter the Amount to be Deposited: ");
//				Scanner scanDep = new Scanner(System.in);
//				depositAmount = scanDep.nextDouble();
//				newDepositAmount = newDepositAmount + depositAmount;
//
//				System.out.println("Press 1 to Continue....");
//				System.out.println("---------------------------------");
//				x = scan.nextInt();
//
//			} while (x == 1);
			
			for (int )

			BankAccount bankObj1 = new BankAccount(accountNumber, accountHolderName, accountBalance, newWithdrawAmount,
					newDepositAmount);
			bankObj1.run();
			bankObj1.printAccount();

		} catch (AccountNumberNegativeException e) {
			e.printStackTrace();
		} catch (BalanceNegativeExceptions e) {
			e.printStackTrace();
		} catch (AccountNameInvalidException e) {
			e.printStackTrace();
		}

		// BankAccount bankObj2 = new BankAccount(200, "Sruthi", 20000);
		// bankObj2.printBankAccount();

		// BankAccount bankObj3 = null;

		// bankObj3 = new BankAccount(300, "Ajay", 50000);
		// bankObj3.printBankAccount();

		// BankAccount bankObj2 = new BankAccount();
		// bankObj1.setBankAccount(200, "Sruthi", 2000000);
		// bankObj1.printBankAccount();

	}

}
