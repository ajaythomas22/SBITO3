package account;

import exceptions.AccountNameInvalidException;
import exceptions.AccountNumberNegativeException;
import exceptions.BalanceNegativeExceptions;
import exceptions.InterestRateNegativeException;

public class SavingsAccount extends BankAccount {

	protected double rateOfInterest;

	SavingsAccount(int x, String y, double z, double r) throws InterestRateNegativeException, AccountNumberNegativeException, BalanceNegativeExceptions, AccountNameInvalidException {
		super(x, y, z);
		System.out.println("SavingsAccount(int,String,double,double)....Contructor invoked");

		if (r < 0) {
			throw new InterestRateNegativeException("Account rate cannot be Negative...Terminating");
		} else
			rateOfInterest = r;
	}

	void printBankAccount() {
		super.printAccount();
		System.out.println("Account Rate of Interest: " + rateOfInterest);
	}

	double calculateSimpleInterest() {
		return (super.accountBalance * 1 * rateOfInterest) / 100;
	}
}
