package exceptions;

public class AccountNumberNegativeException extends Exception {
	
	public AccountNumberNegativeException (String str) {
		super(str);
	}

}
