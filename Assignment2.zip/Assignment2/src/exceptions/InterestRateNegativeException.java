package exceptions;

public class InterestRateNegativeException extends Exception {
	
	public InterestRateNegativeException(String str) {
		super(str);
	}

}
