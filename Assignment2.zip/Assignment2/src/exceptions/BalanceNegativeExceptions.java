package exceptions;

public class BalanceNegativeExceptions extends Exception {
	public BalanceNegativeExceptions(String str) {
		super(str);
	}

}
