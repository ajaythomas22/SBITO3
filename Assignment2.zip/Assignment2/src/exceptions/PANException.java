package exceptions;

public class PANException extends Exception {
	
	public PANException(String str) {
		super(str);
	}

}
