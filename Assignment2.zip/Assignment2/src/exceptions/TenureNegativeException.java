package exceptions;

public class TenureNegativeException extends Exception {
	public TenureNegativeException(String str) {
		super(str);
	}

}
