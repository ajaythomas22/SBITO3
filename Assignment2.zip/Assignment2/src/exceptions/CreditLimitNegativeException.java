package exceptions;

public class CreditLimitNegativeException extends Exception {
	public CreditLimitNegativeException(String str) {
		super(str);
	}

}
