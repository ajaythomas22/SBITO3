package exceptions;

public class AccountNameInvalidException extends Exception {
	
	public AccountNameInvalidException(String str) {
		super(str);
	}

}
