import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PhotoDetails } from './photo-details/PhotoDetails';


@Injectable({
  providedIn: 'root'
})
export class PhotoDetailsService {

  constructor(private myHttp: HttpClient) { }

  loadAllPhotoDetailsService(): Observable<PhotoDetails[]> {
    return this.myHttp.get<PhotoDetails[]>("https://jsonplaceholder.typicode.com/photos")
  }
}
