import { Component, OnInit } from '@angular/core';
import { PhotoDetailsService } from '../photo-details.service';
import { PhotoDetails } from './PhotoDetails';


@Component({
  selector: 'app-photo-details',
  templateUrl: './photo-details.component.html',
  styleUrls: ['./photo-details.component.css']
})
export class PhotoDetailsComponent implements OnInit {

  constructor(private uds: PhotoDetailsService) { }
  photoList: PhotoDetails[] = [];

  ngOnInit(): void {
    this.uds.loadAllPhotoDetailsService().subscribe(
      (data)=> {
          this.photoList = data;
          console.log(this.photoList);
      },
      (err)=> {
        console.log(err);
      }
    );
  }
}
