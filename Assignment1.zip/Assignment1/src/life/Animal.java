package life;

public class Animal extends LivingBeing implements AnimalsDoes{

	@Override
	public void fear() {
		System.out.println("\nAnimals fear death.");
	}

	@Override
	public void eat() {
		System.out.println("Animals eats.");
	}

	@Override
	public void sleep() { 
		System.out.println("Animals sleep.");
	}

	@Override
	public void reproduction() {
		System.out.println("Animals reproduce.");
	}
	
	public Oxygen Levels( ) {   
		
		Oxygen o = null;
		//if (o instanceof Oxygen) {
			System.out.println("\nOxygen Levels is 20.9% in Environment");
		//}
		return o;
	}
}

interface AnimalsDoes {
	
	void fear ();
	void eat();
	void sleep();
	void reproduction();
	
}
