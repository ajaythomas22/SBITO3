package life;

public class Tree extends LivingBeing {

}
