package life;

import animal.Reptile;
import humans.Founder;

public class LivingBeing implements Breathe, Oxygen, CarbonDioxide {

	public static void main(String[] args) {
		
		Founder f = new Founder();
		Animal a = new Animal();
		Reptile r = new Reptile();
		System.out.println("PACKAGE 1: L I F E");
		System.out.println("--------------------------");
		f.breathIn(new LivingBeing());
		f.breathOut(new LivingBeing());
		a.Levels();
		
		f.fear();
		f.reproduction();
		f.eat();
		f.sleep();
		System.out.println("\n--------------------------");
		System.out.println("PACKAGE 2: A N I M AA L");
		System.out.println("--------------------------");
		f.giveBirth();
		r.layLeggs();
		System.out.println("\n--------------------------");
		System.out.println("PACKAGE 3: H U M A N S");
		System.out.println("--------------------------");
		f.think();
		f.active();
		f.study();
		f.work();
		f.execute();
		f.manage();
		f.direct();
		f.found();
				
	}

	@Override
	public void Oxy() {
		System.out.println("Breathes In Oxygen");
	}
	@Override
	public void Carbon() {
		
		System.out.println("Breathes Out Carbon Dioxide");
	}

	@Override
	public void breathIn(Oxygen o2) {

		System.out.println("Living Being is Inhaling.");
		o2.Oxy();
	}

	@Override
	public void breathOut(CarbonDioxide c2) {
		
		System.out.println("\nLiving Being is Exhaling.");
		c2.Carbon();
	}
}

interface Breathe {
	
	void breathIn(Oxygen o2);
	void breathOut(CarbonDioxide o2);
	
}

interface Oxygen {
	
	void Oxy();
}
interface CarbonDioxide {
	
	void Carbon();
}
