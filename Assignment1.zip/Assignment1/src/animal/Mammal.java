package animal;

import life.Animal;

public class Mammal extends Animal implements AnimalDoes {

	@Override
	public void giveBirth() {
		System.out.println("Mammal is giving Birth.");

	}
}

interface AnimalDoes {
	
	void giveBirth ();
}
