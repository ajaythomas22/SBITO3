package animal;

import life.Animal;

public class Reptile extends Animal implements ReptileDoes {

	@Override
	public void layLeggs() {
		System.out.println("Reptile is laying Eggs");
	}
}
interface ReptileDoes {
	void layLeggs();
}
