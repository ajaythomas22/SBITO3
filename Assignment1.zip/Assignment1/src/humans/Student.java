package humans;

public class Student extends Person implements StudentDoes{

	@Override
	public void study() {
		System.out.println("Student is Studying.");	
	}
	

}
interface StudentDoes {
	void study();
}
