package humans;

public class Person extends Human implements PersonDoes {

	@Override
	public void active() {
		System.out.println("Person is Active.");
	}

}

interface PersonDoes {
	void active();
}
