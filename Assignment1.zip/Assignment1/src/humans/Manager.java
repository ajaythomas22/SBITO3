package humans;

public class Manager extends Executive implements ManagerDoes  {

	@Override
	public void manage() {
		System.out.println("Manager is Managing.");
}

}

interface ManagerDoes {
	void manage() ;
}