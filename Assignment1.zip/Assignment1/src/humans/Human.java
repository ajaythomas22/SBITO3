package humans;

import animal.Mammal;

public class Human extends Mammal implements HumanDoes {

	@Override
	public void think() {
		System.out.println("Human is Thinking.");
	}

}

interface HumanDoes {
	void think();
}