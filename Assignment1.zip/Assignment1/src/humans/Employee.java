package humans;

public class Employee extends Student implements EmployeeDoes  {

	@Override
	public void work() {
		System.out.println("Employee is Working.");}

}
interface EmployeeDoes {
	void work() ;
}
