package humans;

public class Director extends Manager implements DiretorDoes {

	@Override
	public void direct() {
		System.out.println("Director is Directing.");
		}
	

}
interface DiretorDoes {
	void direct();
}
