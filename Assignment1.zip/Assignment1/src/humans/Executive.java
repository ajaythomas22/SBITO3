package humans;

public class Executive extends Employee implements ExecutiveDoes {

	@Override
	public void execute() {
		System.out.println("Executive is Executing.");
		}

}

interface ExecutiveDoes {
	void execute();
}