package humans;

public class Founder extends Director implements FounderDoes {

	@Override
	public void found() {
		System.out.println("Found a Company.");	
	}

}

interface FounderDoes {
	void found();
}