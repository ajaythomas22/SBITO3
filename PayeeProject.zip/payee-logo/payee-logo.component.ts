import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { concatMap, delay, of, repeat } from 'rxjs';

@Component({
  selector: 'app-payee-logo',
  templateUrl: './payee-logo.component.html',
  styleUrls: ['./payee-logo.component.css']
})
export class PayeeLogoComponent implements OnInit {
  src$: any;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.src$ = of('../../assets/Banking.png','../../assets/Banking2.png').pipe(
      concatMap(url => of(url).pipe(delay(1500))),
      repeat()
   );
  }
  navigateToDashboard() {

      this.router.navigate(['/dashboard']);
  }
  navigateToAboutUs() {
    this.router.navigate(['/aboutus']);
  }
  navigateToInterest() {
    this.router.navigate(['/interest']);
  }
  navigateToHome() {
    this.router.navigate(['/home']);
  }

}
