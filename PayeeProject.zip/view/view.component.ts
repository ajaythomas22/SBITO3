import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayeeService } from '../payee.service';
import { Payee } from '../payeepage/Payee';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  //payee: Payee = new Payee();
  allpayees: Payee[] = [];
  message!: string;
  acNo: number = 101;

  constructor(private router: Router,private payeeService: PayeeService ) { }

  ngOnInit(): void {
    this.payeeService.loadPayeeOfSingleAccountService(this.acNo).subscribe(
      (data) => {
        console.log('ngOnInit() loading the Payees...');
        this.allpayees = data;
      },
      (err) => {
        console.log(err);
      }
    );
  }
  navigateToHome() {
    this.router.navigate(['/dashboard'])
  }
  logOutThisUser() {
    this.router.navigate(['/login'])
  }
  goToHome() {
    this.router.navigate(['/dashboard'])
  }

  // navigateToDeleteReview() {
  //   this.router.navigate(['/addreview'])
  // }

  // viewAll() {
   
  // }
  
//   editpayee(payeeObj: Payee) {
//     this.payeeService.updateSinglePayeesService(this.acNo, payeeObj.payeeLimit, payeeObj.payeeId).
//     subscribe({
//       next:(data:string) => 
//       { 
//       this.message=data;
//     },
//       error:(err) => { 
//         this.message=err.error;
//     }
//   } );
//   this.viewAll();
// }
navigateToPayee() {
  this.router.navigate(['/payeepage'])
}

}
