import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interestratepage',
  templateUrl: './interestratepage.component.html',
  styleUrls: ['./interestratepage.component.css']
})
export class InterestratepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
