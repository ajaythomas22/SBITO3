import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterestratepageComponent } from './interestratepage.component';

describe('InterestratepageComponent', () => {
  let component: InterestratepageComponent;
  let fixture: ComponentFixture<InterestratepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterestratepageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterestratepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
