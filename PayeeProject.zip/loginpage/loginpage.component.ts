import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { concatMap, delay, of, repeat } from 'rxjs';
import { User } from './User';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  src$: any;
  userObj: User =new User()
  constructor(private router:Router) { }

  ngOnInit(): void {
   
  }
  authenticate() {
    this.router.navigate(['/payeepage']);
    // if(this.userObj.username=='admin' && this.userObj.password=="admin123") {
    //   console.log("Welcome Admin");
    //   this.router.navigate(['/payeepage']);
    // }
    // else {
    //   console.log("Welcome End-User");
    //   this.router.navigate(['/home']);
    // }
  }

  navigateTo() {
      this.router.navigate(['/login']);
  }

}
