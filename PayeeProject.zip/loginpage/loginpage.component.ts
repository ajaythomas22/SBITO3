import { Component, OnInit } from '@angular/core';
import { concatMap, delay, of, repeat } from 'rxjs';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  src$: any;

  constructor() { }

  ngOnInit(): void {
    this.src$ = of('../../assets/Banking.png','../../assets/Banking2.png').pipe(
      concatMap(url => of(url).pipe(delay(1500))),
      repeat()
   );
  }

}
