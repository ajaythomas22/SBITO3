import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payee } from './payeepage/Payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {

  constructor(private myHttp: HttpClient) { }

  // loadAllPayeesService() : Observable<Payee[]> { // localhost:4200
  //   console.log('loadAllPayeesService() invoked.....');
  //   return this.myHttp.get<Payee[]>("http://localhost:8080/payee/");
  // }
  loadPayeeOfSingleAccountService(acNo:number) : Observable<Payee[]> { // localhost:4200
    console.log('loadSinglePayeesService() invoked.....');
    return this.myHttp.get<Payee[]>("http://localhost:8080/payee/"+acNo);
  }
  // addSinglePayeesService(accNo:number,payee:Payee) : Observable<string> { // localhost:4200
  //   console.log('addSinglePayeesService() invoked.....');
  //   return this.myHttp.post<string>('http://localhost:8080/payee/addPayee/${accNo}/${payee}',{ responseType: 'text' as 'json'});
  // }
  addSinglePayeesService(payee:Payee) : Observable<string> { // localhost:4200
    console.log('addSinglePayeesService() invoked.....');
    return this.myHttp.post<string>("http://localhost:8080/payee/addPayee/101/",payee,{ responseType: 'text' as 'json'});
  }
  updateSinglePayeesService(accNo:number,payeeLimit : number , payeeId: number) : Observable<string> { // localhost:4200
    console.log('addSinglePayeesService() invoked.....');
    return this.myHttp.put<string>("http://localhost:8080/payee/updatePayee/",accNo+"/"+payeeLimit+"/"+payeeId,{ responseType: 'text' as 'json'});
  }

  deleteSinglePayeeByAccountNoService(acNo:number, payeeId: number) : Observable<string> { // localhost:4200
    console.log('deleteSinglePayeeService() invoked.....');
    return this.myHttp.delete<string>(`http://localhost:8080/payee/deletePayee/${acNo}/${payeeId}`,{ responseType: 'text' as 'json'});
  }  

}
