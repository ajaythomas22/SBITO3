import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayeeService } from '../payee.service';
import { Payee } from '../payeepage/Payee';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  payeeType:String="";
  show:boolean=false;
  message!: string;
  accObj: any;
  accNo: number = 101;
  constructor(private router: Router, private payeeService: PayeeService) { }

  payeeObj: Payee = new Payee();
  ngOnInit(): void {
  }

  toggleIfsc()
  {
    console.log("toggle");
    console.log(this.payeeType);

    if(this.payeeType==="Intra-Bank Account"){
        this.show=false;
    }
    else if(this.payeeType==="Inter-Bank Account"){
      this.show=true;
    }
    
  }
  addPayeeToAccount(payeeObj1: any) {
   
    this.payeeService.addSinglePayeesService(payeeObj1).subscribe( {
      next:(data:string) => 
      { 
      this.message=data;
        // this.accObj.payeeList.push(payeeObj1);
    },
      error:(err) => { 
        this.message=err.error;
    }
  } );
}

}
