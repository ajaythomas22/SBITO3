import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayeeService } from '../payee.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-payeepage',
  templateUrl: './payeepage.component.html',
  styleUrls: ['./payeepage.component.css']
})
export class PayeepageComponent implements OnInit {

  show: boolean = false;
  v: boolean = false;
  a: boolean = false;
  d: boolean = false;
  payee: Payee = new Payee();

  allpayees: Payee[] = [];

  constructor(private router:Router, private payeeService: PayeeService) { }

  ngOnInit(): void {

  }
  showView(){
    this.v = !this.v;
    this.a = false;
    this.d = false;
  }
  showAdd(){
    this.a = !this.a;
    this.d = false;
    this.v = false;
  }
  showDelete(){
    this.d = !this.d;
    this.a = false;
    this.v = false;
  }

  logOutThisUser() {
    this.router.navigate(['/login'])
  }
  goToHome() {
    this.router.navigate(['/dashboard'])
  }
  // viewAll() {
  //   this.payeeService.loadAllPayeesService().subscribe(
  //     (data) => {
  //       console.log('ngOnInit() loading the Payees...');
  //       this.allpayees = data;
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );
  // }

  message!: string;
  acNo: number = 101;

  deleteThis(x: number) {
    this.payeeService.deleteSinglePayeeByAccountNoService(this.acNo,this.payee.payeeId).subscribe({
      next:(data:string) => 
      { 
      this.message=data;
    },
      error:(err) => { 
        this.message=err.error;
    }
  } );
  //this.viewAll();
}

  }
