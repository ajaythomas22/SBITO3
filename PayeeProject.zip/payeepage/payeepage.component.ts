import { Component, OnInit } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@Component({
  selector: 'app-payeepage',
  templateUrl: './payeepage.component.html',
  styleUrls: ['./payeepage.component.css']
})
export class PayeepageComponent implements OnInit {

  show: boolean = false;
  v: boolean = false;
  a: boolean = false;
  d: boolean = false;
  panelOpenState: boolean = false;

  constructor() { }

  ngOnInit(): void {

  }
  showView(){
    this.v = !this.v;
    this.a = false;
    this.d = false;
  }
  showAdd(){
    this.a = !this.a;
    this.d = false;
    this.v = false;
  }
  showDelete(){
    this.d = !this.d;
    this.a = false;
    this.v = false;
  }
  // toggleIfsc(){
  //   console.log("toggle");
  //   console.log(this.payeeType);
  //   console.log(this.menuIdentifier);
  //   if (this.payeeType === "Own Bank Account") {
  //     this.show = false;
  //   }
  //   else if (this.payeeType === "Other Bank Account") {
  //     this.show = true;
  //   }
  navigateToAdd()
   {

   }
  navigateToView()
   {

   }
  navigateToDelete()
   {
     
   }
  }

