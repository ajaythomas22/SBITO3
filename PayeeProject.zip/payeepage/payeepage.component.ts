import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payeepage',
  templateUrl: './payeepage.component.html',
  styleUrls: ['./payeepage.component.css']
})
export class PayeepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
