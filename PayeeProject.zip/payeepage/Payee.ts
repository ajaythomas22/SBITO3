export class Payee {
    
    payeeId!: number;
    payeeAcctNo!: number;
    payeeName!: string;
    PayeeNickName!:string;
    payeeLimit!: number;
    
}