import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { AboutuspageComponent } from './aboutuspage/aboutuspage.component';
import { InterestratepageComponent } from './interestratepage/interestratepage.component';
import { PayeepageComponent } from './payeepage/payeepage.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddComponent } from './add/add.component';
import { ViewComponent } from './view/view.component';
import { ModifyComponent } from './modify/modify.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DeletereviewComponent } from './deletereview/deletereview.component';
import { AddreviewComponent } from './addreview/addreview.component';
import { AccountUserComponent } from './account-user/account-user.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    AboutuspageComponent,
    InterestratepageComponent,
    PayeepageComponent,
    HomeComponent,
    DashboardComponent,
    AddComponent,
    ViewComponent,
    ModifyComponent,
    DeletereviewComponent,
    AddreviewComponent,
    AccountUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CommonModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
