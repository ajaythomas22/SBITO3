import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { AboutuspageComponent } from './aboutuspage/aboutuspage.component';
import { InterestratepageComponent } from './interestratepage/interestratepage.component';
import { PayeepageComponent } from './payeepage/payeepage.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    AboutuspageComponent,
    InterestratepageComponent,
    PayeepageComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
