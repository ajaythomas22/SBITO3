import { Component, OnInit } from '@angular/core';
import { Account } from '../account-user/Account';
import { PayeeService } from '../payee.service';
import { Payee } from '../payeepage/Payee';

@Component({
  selector: 'app-addreview',
  templateUrl: './addreview.component.html',
  styleUrls: ['./addreview.component.css']
})
export class AddreviewComponent implements OnInit {

  payee: Payee = new Payee();
  message!:string;
  accObj: Account = new Account();
  acNo: number = 101;

  constructor(private payeeService: PayeeService) { }

  ngOnInit(): void {
  }
  // addPayeeToAccount() {
   
  //     this.payeeService.addSinglePayeesService(this.acNo, this.payee).subscribe( {
  //       next:(data:string) => 
  //       { 
  //       this.message=data;
  //         this.accObj.payeeList.push(this.payee);
  //     },
  //       error:(err) => { 
  //         this.message=err.error;
  //     }
  //   } );
  // }
}
