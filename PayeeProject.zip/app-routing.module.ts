import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutuspageComponent } from './aboutuspage/aboutuspage.component';
import { AddComponent } from './add/add.component';
import { AddreviewComponent } from './addreview/addreview.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DeletereviewComponent } from './deletereview/deletereview.component';
import { HomeComponent } from './home/home.component';
import { InterestratepageComponent } from './interestratepage/interestratepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ModifyComponent } from './modify/modify.component';
import { PayeepageComponent } from './payeepage/payeepage.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [

  {path: 'home',component:HomeComponent},
  {path: 'aboutus', component: AboutuspageComponent},
  {path: 'interestrate', component: InterestratepageComponent},
  {path: 'login', component: LoginpageComponent},
  {path:'dashboard',component:DashboardComponent},
  {path: 'payeepage',component: PayeepageComponent},
  {path: 'add', component: AddComponent},
  {path:'view', component: ViewComponent},
  {path: 'modify', component: ModifyComponent},
  {path:'addreview',component: AddreviewComponent},
  {path:'deletereview', component: DeletereviewComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
