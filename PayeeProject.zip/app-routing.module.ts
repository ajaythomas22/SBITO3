import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutuspageComponent } from './aboutuspage/aboutuspage.component';
import { HomeComponent } from './home/home.component';
import { InterestratepageComponent } from './interestratepage/interestratepage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { PayeepageComponent } from './payeepage/payeepage.component';

const routes: Routes = [

  {path: 'home',component:HomeComponent},
  {path: 'aboutus', component: AboutuspageComponent},
  {path: 'interestrate', component: InterestratepageComponent},
  {path: 'login', component: LoginpageComponent},
  {path: 'payeepage',component: PayeepageComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
