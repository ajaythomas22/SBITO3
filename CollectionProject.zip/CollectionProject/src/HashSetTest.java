import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class HashSetTest {

	public static void main(String[] args) {
		HashSet myList = new HashSet();
		Scanner scan = new Scanner(System.in);
		int c = 0, num = 0, total = 0;
		do {
			System.out.println("Enter the Runs scored: ");
			num = scan.nextInt();
			myList.add(num);
			total = total + num;
			System.out.println("Press 0 to continue");
			c = scan.nextInt();
		} while (c == 0);
		System.out.println("----------------------------");
		System.out.println("Total Runs Scored: " + total);

		Iterator iter = myList.iterator();

		System.out.println("----------------------------");
		while (iter.hasNext()) {
			Integer iValue = (Integer) iter.next();
			System.out.println("Value is " + iValue);

		}

	}

}
