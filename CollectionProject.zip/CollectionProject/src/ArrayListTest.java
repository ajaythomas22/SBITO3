import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayListTest {

	public static void main(String[] args) {
		
		ArrayList myList = new ArrayList();
		Scanner scan = new Scanner(System.in);
		int c =0, num=0, total=0;
		do {
			System.out.println("Enter the Runs scored: ");
			num= scan.nextInt();
			myList.add(num);
			total = total + num;
			System.out.println("Press 0 to continue");
			c=scan.nextInt();
		} while (c==0);
		System.out.println("----------------------------");
		System.out.println("Total Runs Scored: " +total);
		
		Iterator iter = myList.iterator();
		
		while(iter.hasNext()) {
			Integer iValue = (Integer) iter.next();
			System.out.println("----------------------------");
			System.out.println("Value is "+iValue);
		}
		
//		int arrayIndia[] = new int[11];
//		int arrayEngl[] = {5,10,15,25,35,15,10,70,52,31,0};
//		arrayIndia[0] = 10;
//		arrayIndia[1] = 20;
//		arrayIndia[2] = 30;
//		arrayIndia[3] = 40;
//		arrayIndia[4] = 50;
//		arrayIndia[5] = 60;
//		arrayIndia[6] = 70;
//		arrayIndia[7] = 80;
//		arrayIndia[8] = 90;
//		arrayIndia[9] = 15;
//		arrayIndia[10] = 25;
		
//		int totalInd = 0, totalAus = 0;
//		for (int i = 0; i < arrayIndia.length; i++) {
//			totalInd = totalInd + arrayIndia[i];
//		}
//		for (int i = 0; i < arrayEngl.length; i++) {
//			if(arrayEngl[i]==0)
//			totalAus = totalAus + arrayEngl[i];
//		}
//		
//		System.out.println("Total Runs of India: "+totalInd);
//		System.out.println("Total Runs of England: "+totalAus);
		
	}
	

}
