import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;
import com.sbi.exceptions.ApplicantNotFoundException;


public class SQLTestQueries {

	public static void main(String[] args) {
		
		DeleteQuery dq = new DeleteQuery();

	}
}

//class SelectQuery {
//	
//	public SelectQuery() {
//		try {
//			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
//			System.out.println("Driver Loaded/Registered..");
//			
//			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb","SA","");
//			System.out.println("Connected to DB");
//			
//			Statement st = conn.createStatement();
//			System.out.println("Statement Created");
//			
//			ResultSet rs = st.executeQuery("SELECT * FROM BANK_APPLICANT");
//			System.out.println("Query fired...Got the results");
//			
//			while(rs.next()) {
//				System.out.println("APPLICANT ID: " +rs.getInt(1));
//				System.out.println("APPLICANT NAME: " +rs.getString(2));
//				System.out.println("APPLICANT EMAIL: " +rs.getString(3));
//				System.out.println("APPLICANT MOBILE: " +rs.getString(4));
//				System.out.println("APPLICANT DOB: " +rs.getDate(5));
//				System.out.println("APPLICANT ADDRESS: " +rs.getString(6));
//				System.out.println("------------------------------");
//			}
//			rs.close();
//			st.close();
//			conn.close();
//			System.out.println("Disconnected from DB");
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
//}
class DeleteQuery {
	public DeleteQuery() {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Loaded/Registered..");
			
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb","SA","");
			System.out.println("Connected to DB");
			
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the Application ID to be Deleted ");
			int applID = scan.nextInt();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM BANK_APPLICANT");
			PreparedStatement pst = conn.prepareStatement("DELETE FROM BANK_APPLICANT WHERE APPLICANT_ID= ?"+applID);
			
			do 
			{ 
				if(applID==rs.getInt(1))
				{
					pst.setInt(1, applID);
				}
				else 
				{
					throw new ApplicantNotFoundException("Application ID does not Exist!!!");
				}
			} while(rs.next());
		
			int row = pst.executeUpdate();
			System.out.println("Row Deleted ..." + row);
			
			rs.close();
			pst.close();
			conn.close();
			System.out.println("Disconnected from the db....");
		}
		catch (SQLException e) {
			System.out.println("Some problem 1 : " + e);
		}
		catch (ApplicantNotFoundException e) {
			System.out.println("Some problem 2 : " + e);
		}
	}

}

//class UpdateQuery {
//	public UpdateQuery() {
//		try {
//			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
//			System.out.println("Driver loaded.../registered....");
//
//			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
//			System.out.println("Connected to the db....");
//
//			PreparedStatement pst = conn.prepareStatement(
//					"UPDATE BANK_APPLICANT SET APPLICANT_NAME=?, APPLICANT_ADDRESS=? WHERE APPLICANT_ID=?");
//			pst.setString(1, "JACKSON");
//			pst.setString(2, "CBD BELAPUR");
//			pst.setInt(3, 123);
//			System.out.println("prepared statement is created..." + pst);
//
//			int row = pst.executeUpdate();
//			System.out.println("row UPDATED..." + row);
//
//			pst.close();
//			conn.close();
//			System.out.println("DisConnected from the db....");
//
//		} catch (SQLException e) {
//			System.out.println("Some problem : " + e);
//		}
//	}
//}
//
//class InsertQuery {
//	public InsertQuery() {
//		try {
//			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
//			System.out.println("Driver loaded.../registered....");
//
//			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
//			System.out.println("Connected to the db....");
//
//			PreparedStatement pst = conn.prepareStatement(
//					"UPDATE BANK_APPLICANT SET APPLICANT_NAME=?, APPLICANT_ADDRESS=? WHERE APPLICANT_ID=?");
//			pst.setString(1, "JACKSON");
//			pst.setString(2, "CBD BELAPUR");
//			pst.setInt(3, 123);
//			System.out.println("prepared statement is created..." + pst);
//
//			int row = pst.executeUpdate();
//			System.out.println("row UPDATED..." + row);
//
//			pst.close();
//			conn.close();
//			System.out.println("DisConnected from the db....");
//
//		} catch (SQLException e) {
//			System.out.println("Some problem : " + e);
//		}
//	}
//
//}