import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;
import com.sbi.exceptions.ApplicantNotFoundException;
import com.sbi.exceptions.EmailIDFoundException;

public class SQLTestQueries {

	public static void main(String[] args) {

		System.out.println("\tDATABASE QUERIES");
		System.out.println("------------------------------");
		int choice = 0;
		System.out.println("1. Delete a record with Applicant ID");
		System.out.println("2. Insert a new record");
		System.out.println("3. Update an existing record");
		System.out.println("\nEnter your choice: ");
		System.out.println();
		
		Scanner scan = new Scanner(System.in);
		choice = scan.nextInt();
		switch (choice) {
		case 1:
			DeleteQuery dq = new DeleteQuery();
			break;
		case 2:
			InsertQuery iq = new InsertQuery();
			break;
		case 3:
			UpdateQuery uq = new UpdateQuery();
			break;
		default:
			System.out.println("Invalid Choice!!!");
		}
	}
}

class UpdateQuery {
	public UpdateQuery() {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Loaded/Registered..");

			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to DB");

			PreparedStatement pst = conn.prepareStatement(
					"UPDATE BANK_APPLICANT SET APPLICANT_NAME=?, APPLICANT_ADDRESS=? WHERE APPLICANT_ID=?");
			pst.setString(1, "JACKSON");
			pst.setString(2, "CBD BELAPUR");
			pst.setInt(3, 123);

			int row = pst.executeUpdate();
			System.out.println("Rows Updated" + row);

			pst.close();
			conn.close();
			System.out.println("Disconnected from DB!!");

		} catch (SQLException e) {
			System.out.println("Some problem : " + e);
		}
	}
}

class DeleteQuery {
	public DeleteQuery() {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Loaded/Registered..");

			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to DB");

			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the Applicant ID to be Deleted ");
			int applID = scan.nextInt();

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_ID= " + applID);
			PreparedStatement pst = conn.prepareStatement("DELETE FROM BANK_APPLICANT WHERE APPLICANT_ID= " + applID);

			if (rs.next()) {
				int row = pst.executeUpdate();
				System.out.println("Rows Deleted " + row);
			} else {
				throw new ApplicantNotFoundException("Application ID does not Exist!!!");
			}

			rs.close();
			pst.close();
			conn.close();
			System.out.println("Disconnected from DB!!");
		} catch (ApplicantNotFoundException e) {
			System.out.println("Some problem 2 : " + e);
		} catch (SQLException e) {
			System.out.println("Some problem 1 : " + e);
		}

	}

}

class InsertQuery {
	public InsertQuery() {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Loaded/Registered..");

			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to DB");

			System.out.println("Enter the Values to be Inserted in DB");
			System.out.println("-------------------------------------");
			Scanner scan1 = new Scanner(System.in);
			System.out.println("\nEnter the Applicant ID:  ");
			int applID = scan1.nextInt();

			Scanner scan2 = new Scanner(System.in);
			System.out.println("Enter the Applicant Name:  ");
			String applName = scan2.nextLine();

			Scanner scan3 = new Scanner(System.in);
			System.out.println("Enter the Applicant Email:  ");
			String applEmail = scan3.nextLine();

			Scanner scan4 = new Scanner(System.in);
			System.out.println("Enter the Applicant Mobile No:  ");
			String applMobile = scan4.nextLine();

			Scanner scan5 = new Scanner(System.in);
			System.out.println("Enter the Applicant Address:  ");
			String applAddr = scan4.nextLine();

//			Scanner scanner = new Scanner("December 6, 2013other fields");
//		    scanner.useDelimiter(",");

//		    String dateString = scanner.next();
//		    DateFormat formatter = new SimpleDateFormat("EEEE dd MMM yyyy");
//		    Date date = formatter.parse(dateString);

			Statement st = conn.createStatement();
			ResultSet rs = st
					.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_EMAIL_ADDRESS='" + applEmail + "'");
			PreparedStatement pst = conn.prepareStatement("INSERT INTO BANK_APPLICANT VALUES (?,?,?,?,?,?) ");

			pst.setInt(1, applID);
			pst.setString(2, applName);
			pst.setString(3, applEmail);
			pst.setString(4, applMobile);
			pst.setDate(5, null);
			pst.setString(6, applAddr);

			if (rs.next()) {

				throw new EmailIDFoundException("Email ID already Exist");

			} else {
				int row = pst.executeUpdate();
				System.out.println("Rows Inserted" + row);
			}

//			Calendar cal = Calendar.getInstance();
//			java.util.Date date = cal.getTime();
//			
//			java.sql.Date sqlDate= new java.sql.Date(date.getTime());
//			pst.setDate(5,sqlDate);;
//			
//			Scanner scan5 = new Scanner(System.in);
//			System.out.println("Enter the Applicant Address:  ");
//			String applAddr = scan3.nextLine();

			System.out.println("-------------------------------------");

			rs.close();
			pst.close();
			conn.close();
			scan1.close();
			scan2.close();
			scan3.close();
			scan4.close();
			System.out.println("DisConnected from DB");

		} catch (SQLException e) {
			System.out.println("Some problem : " + e);
		} catch (EmailIDFoundException e) {
			System.out.println("Some problem : " + e);
		}
	}

}