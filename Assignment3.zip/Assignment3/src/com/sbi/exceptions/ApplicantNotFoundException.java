package com.sbi.exceptions;

public class ApplicantNotFoundException extends Exception {
	
	public ApplicantNotFoundException(String str) {
		super(str);
	}

}
