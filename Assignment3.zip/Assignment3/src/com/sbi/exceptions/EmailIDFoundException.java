package com.sbi.exceptions;

public class EmailIDFoundException extends Exception {
	
	public EmailIDFoundException(String str) {
		super(str);
	}

}
