import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payee-management',
  templateUrl: './payee-management.component.html',
  styleUrls: ['./payee-management.component.css']
})
export class PayeeManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
