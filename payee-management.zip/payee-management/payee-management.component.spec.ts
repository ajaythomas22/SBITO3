import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeManagementComponent } from './payee-management.component';

describe('PayeeManagementComponent', () => {
  let component: PayeeManagementComponent;
  let fixture: ComponentFixture<PayeeManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayeeManagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
