import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from './account-user/Account';
import { Payee } from './payeepage/Payee';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private myHttp: HttpClient) { }

  // loadAllPayeesService() : Observable<Payee[]> { // localhost:4200
  //   console.log('loadAllPayeesService() invoked.....');
  //   return this.myHttp.get<Payee[]>("http://localhost:8080/payee/");
  // }
  loadSingleAccountService(acNo:number) : Observable<Account> { // localhost:4200
    console.log('loadSingleAccountService() invoked.....');
    return this.myHttp.get<Account>("http://localhost:8080/accts/"+acNo);
  }
}
