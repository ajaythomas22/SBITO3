import { Payee } from "../payeepage/Payee";

export class Account {

    acctNo!: number;
    acctName!: string;
    mailId!: string;
    accBal!: number;
    username!: string;
    password!: string;
    payeeList!: Payee[]; 
     
}