import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Account } from '../account-user/Account';
import { PayeeService } from '../payee.service';
import { AnyObject } from '../payeepage/AnyObject';
import { Payee } from '../payeepage/Payee';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  payeeType:String="";
  show:boolean=false;
  showA:boolean=true;
  showR:boolean=false;
  message!: string;
  //accNum: number = 101;
 // payee: Payee = new Payee();
 // accObj: Account = new Account();

  rePayeeAcctNo!:number;
  anyObj:AnyObject=new AnyObject();
  requiredForm!: FormGroup;

  tempAccNo!:any;
  accNo!:number;
  constructor(private router: Router, private payeeService: PayeeService, private fb: FormBuilder)
  { 
    this.tempAccNo=sessionStorage.getItem("x");
    console.log(this.tempAccNo);
    this.accNo=JSON.parse(this.tempAccNo);
    this.myForm();

  }

  payeeObj: Payee = new Payee();
  ngOnInit(): void {
  }
  myForm() {
       this.requiredForm = this.fb.group( { 
      uname:['', Validators.required],
      upass:['', Validators.required],
    })
  }

  toggleIfsc()
  {
    console.log("toggle");
    console.log(this.payeeType);

    if(this.payeeType==="Intra-Bank Account"){
        this.show=false;
    }
    else if(this.payeeType==="Inter-Bank Account"){
      this.show=true;
    }
    
  }
  addPayeeToAccount() {
    
    this.anyObj.accNum=this.accNo;

    //console.log("Addition of Payee started in Angular...")

    this.payeeService.addSinglePayeesService(this.anyObj).subscribe( {
      next:(data:string) => 
      { 
      this.message=data;
      //this.accObj.payeeList.push(payeeObj1);
    },
      error:(err) => { 
        this.message=err.error;
    }
  } );
}
navigateToPayee() {
    this.router.navigate(['/payeepage'])
  }

  navigateToHome() {
    this.router.navigate(['/dashboard'])
  }
  logOutThisUser() {
    this.router.navigate(['/home'])
  }
  goToHome() {
    this.router.navigate(['/dashboard'])
  }
  showReview() {
      this.showR=true;
      this.showA=false;
      console.log(this.showA);
      console.log(this.showR);
  }

}
