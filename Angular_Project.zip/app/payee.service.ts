import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MyResponse } from './modify/MyResponse';
import { AnyObject } from './payeepage/AnyObject';
import { Payee } from './payeepage/Payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {

  constructor(private myHttp: HttpClient) { }

  // loadAllPayeesService() : Observable<Payee[]> { // localhost:4200
  //   console.log('loadAllPayeesService() invoked.....');
  //   return this.myHttp.get<Payee[]>("http://localhost:8080/payee/");
  // }
  loadPayeeOfSingleAccountService(acNo:number) : Observable<Payee[]> { // localhost:4200
    console.log('loadSinglePayeesService() invoked.....');
    return this.myHttp.get<Payee[]>("http://localhost:8080/payee/"+acNo);
  }
  // addSinglePayeesService(accNo:number,payee:Payee) : Observable<string> { // localhost:4200
  //   console.log('addSinglePayeesService() invoked.....');
  //   return this.myHttp.post<string>('http://localhost:8080/payee/addPayee/${accNo}/${payee}',{ responseType: 'text' as 'json'});
  // }
  addSinglePayeesService(anyObj:AnyObject) : Observable<string> { // localhost:4200
    console.log('addSinglePayeesService() invoked.....');
    return this.myHttp.post<string>("http://localhost:8080/payee/addPayee/",anyObj,{ responseType: 'text' as 'json'});
  }
  updateSinglePayeesService(accNo:number, payeeId: number,payeeLimit : number ) : Observable<MyResponse> { // localhost:4200
    console.log('addSinglePayeesService() invoked.....');
    return this.myHttp.put<MyResponse>("http://localhost:8080/payee/updatePayee/"+accNo+"/"+payeeId+"/"+payeeLimit,{ responseType: 'text' as 'json'});
  }

  deleteSinglePayeeByAccountNoService(acNo:number, payeeId: number) : Observable<string> { // localhost:4200
    console.log('deleteSinglePayeeService() invoked.....');
    return this.myHttp.delete<string>(`http://localhost:8080/payee/deletePayee/${acNo}/${payeeId}`,{ responseType: 'text' as 'json'});
  }  

}
