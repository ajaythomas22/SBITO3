import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-interestratepage',
  templateUrl: './interestratepage.component.html',
  styleUrls: ['./interestratepage.component.css']
})
export class InterestratepageComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  navigateToAboutUs() {
    this.router.navigate(['/aboutus']);
  }
  navigateToInterest() {
    this.router.navigate(['/interest']);
  }
  navigateToHome() {
    this.router.navigate(['/home']);
  }

}
