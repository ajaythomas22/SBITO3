export class MyResponse{
    message!:string;

}