import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayeeService } from '../payee.service';
import { Payee } from '../payeepage/Payee';
import { MyResponse } from './MyResponse';

@Component({
  selector: 'app-modify',
  templateUrl: './modify.component.html',
  styleUrls: ['./modify.component.css']
})
export class ModifyComponent implements OnInit {

  //payee: Payee = new Payee();
  allpayees: Payee[] = [];
  message!: string;
  //acNo: number = 101;
  //myResponse!:MyResponse;
  tempAccNo!:any;
  accNo!:number;
  constructor(private router: Router,private payeeService: PayeeService ) { 
    this.tempAccNo=sessionStorage.getItem("x");
    console.log(this.tempAccNo);
    this.accNo=JSON.parse(this.tempAccNo);
  }

  ngOnInit(): void {
    this.payeeService.loadPayeeOfSingleAccountService(this.accNo).subscribe(
      (data) => {
        console.log('ngOnInit() loading the Payees...');
        this.allpayees = data;
      },
      (err) => {
        console.log(err);
      }
    );
  }
  deletePayee(pid:number)
  {
    this.payeeService.deleteSinglePayeeByAccountNoService(this.accNo,pid).subscribe(
      {
        next:(data:string) =>{
        this.message=data;
      },
      error:(err) =>{
        this.message=err.error;
      }
    }
    );
  }
  updatePayee(pid:number,plimit:number){
    this.payeeService.updateSinglePayeesService(this.accNo,pid,plimit).subscribe(
      {
        next:(data:MyResponse) =>{
        this.message=data.message;
      },
      error:(err) =>{
        this.message=err.error;
      }
    }
    );
  }
  navigateToHome() {
    this.router.navigate(['/dashboard'])
  }
  logOutThisUser() {
    this.router.navigate(['/home'])
  }
  goToHome() {
    this.router.navigate(['/dashboard'])
  }
  navigateToPayee() {
    this.router.navigate(['/payeepage'])
  }
  // navigateToDeleteReview() {
  //   this.router.navigate(['/addreview'])
  // }

  // viewAll() {
   
  // }
  
//   editpayee(payeeObj: Payee) {
//     this.payeeService.updateSinglePayeesService(this.acNo, payeeObj.payeeLimit, payeeObj.payeeId).
//     subscribe({
//       next:(data:string) => 
//       { 
//       this.message=data;
//     },
//       error:(err) => { 
//         this.message=err.error;
//     }
//   } );
//   this.viewAll();
// }


}
