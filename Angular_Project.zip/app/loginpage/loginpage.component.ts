import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { concatMap, delay, of, repeat } from 'rxjs';
import { AccountUserComponent } from '../account-user/account-user.component';
import { Account } from '../account-user/Account';
import { HttpClient } from '@angular/common/http';
import { AccountService } from '../account.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  src$: any;
  loginu!: number;
  loginp!: string;
  tempAcc: Account=new Account();
  accObj: Account = new Account();
  requiredForm!: FormGroup;

  constructor(private router:Router, private accountService: AccountService, private fb: FormBuilder) { }

  ngOnInit(): void {
   console.log('Entered acc:'+this.loginu);

   this.src$ = of('../../assets/PIC1.jpg','../../assets/PIC2.jpg',
   '../../assets/PIC3.png','../../assets/PIC4.jpg','../../assets/PIC5.jpg').pipe(
    concatMap(url => of(url).pipe(delay(1500))),
    repeat() );
  }
  myForm() {
    this.requiredForm = this.fb.group( { 
   uname:['', Validators.required],
   upass:['', Validators.required],
 })
}

  //message!: string;
  authenticate() {
    console.log(this.loginu);
    this.accountService.loadSingleAccountService(this.loginu).subscribe(
      (data) => {
        console.log('ngOnInit() loading the Account..');
        this.tempAcc = data;
        console.log("Data is" +data);
        console.log('Acc is'+this.tempAcc.acctName);
        sessionStorage.setItem("x", JSON.stringify(this.tempAcc));

        if(this.loginu==this.tempAcc.acctNo && this.loginp==this.tempAcc.password)
                this.router.navigate(['/dashboard']);
        else alert("Invalid Credentials");
      },
      (err) => {
        console.log(err);
      }
    );
  }
      // if(this.accObj.acctNo==this.loginu && this.accObj.password==this.loginp) {
    //   console.log("Welcome User :"+this.loginu);
    //   this.router.navigate(['/dashboard']);
    // }
    navigateToAboutUs() {
      this.router.navigate(['/aboutus']);
    }
    navigateToInterest() {
      this.router.navigate(['/interestrate']);
    }
    navigateToHome() {
      this.router.navigate(['/home']);
    }
  }

// function data(data: any): ((value: Account) => void) | Partial<import("rxjs").Observer<Account>> | null | undefined {
//   throw new Error('Function not implemented.');


