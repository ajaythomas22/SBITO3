import { Payee } from "./Payee";

export class AnyObject
{
    accNum!: number;
    payeeObj:Payee=new Payee();
}