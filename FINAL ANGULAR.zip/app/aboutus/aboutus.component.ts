import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  navigateToAboutUs() {
    this.router.navigate(['/aboutus']);
  }
  navigateToInterest() {
    this.router.navigate(['/interest']);
  }
  navigateToHome() {
    this.router.navigate(['/home']);
  }

}
