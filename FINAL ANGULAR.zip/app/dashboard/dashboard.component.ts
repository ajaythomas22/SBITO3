import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from '../account-user/Account';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private router:Router) { }
  accObj:Account = new Account();
  anyObj!:any;

  ngOnInit(): void {

    this.anyObj = sessionStorage.getItem("x");
    console.log('Users data:'+this.anyObj);
    this.accObj=JSON.parse(this.anyObj);
  }

  navigateToPayeePage() {
    this.router.navigate(['/payeepage']);
    sessionStorage.setItem("x",JSON.stringify( this.accObj.acctNo));
  }
  logOutThisUser() {
    this.router.navigate(['/home'])
  }
  goToHome() {
    this.router.navigate(['/dashboard'])
  }


}
