import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PayeeLogoComponent } from './payee-logo/payee-logo.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { InterestComponent } from './interest/interest.component';
import { PayeepageComponent } from './payeepage/payeepage.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatTabsModule} from '@angular/material/tabs';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AddComponent } from './add/add.component';
import { ViewComponent } from './view/view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModifyComponent } from './modify/modify.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AccountUserComponent } from './account-user/account-user.component';

@NgModule({
  declarations: [
    AppComponent,
    PayeeLogoComponent,
    AboutusComponent,
    InterestComponent,
    PayeepageComponent,
    AddComponent,
    ViewComponent,
    ModifyComponent,
    DashboardComponent,
    AccountUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatTabsModule,
    FormsModule,
    HttpClientModule,    
    ReactiveFormsModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
