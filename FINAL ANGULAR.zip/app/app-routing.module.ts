import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddComponent } from './add/add.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InterestComponent } from './interest/interest.component';
import { ModifyComponent } from './modify/modify.component';
import { PayeeLogoComponent } from './payee-logo/payee-logo.component';
import { PayeepageComponent } from './payeepage/payeepage.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [

    {path:'home',component:PayeeLogoComponent},
    {path:'aboutus',component:AboutusComponent},
    {path:'interest',component:InterestComponent},
    {path:'dashboard',component:DashboardComponent},
    {path:'payeepage', component: PayeepageComponent},
    {path:'add', component: AddComponent },
    {path:'view', component:ViewComponent},
    {path:'modify',component:ModifyComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
