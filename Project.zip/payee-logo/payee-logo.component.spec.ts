import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeLogoComponent } from './payee-logo.component';

describe('PayeeLogoComponent', () => {
  let component: PayeeLogoComponent;
  let fixture: ComponentFixture<PayeeLogoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayeeLogoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeLogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
