import { Component, OnInit } from '@angular/core';
import { concatMap, delay, of, repeat } from 'rxjs';

@Component({
  selector: 'app-payee-logo',
  templateUrl: './payee-logo.component.html',
  styleUrls: ['./payee-logo.component.css']
})
export class PayeeLogoComponent implements OnInit {
  src$: any;

  constructor() { }

  ngOnInit(): void {
    this.src$ = of('../../assets/Banking.png','../../assets/Banking2.png').pipe(
      concatMap(url => of(url).pipe(delay(1000))),
      repeat()
   );
  }

}
