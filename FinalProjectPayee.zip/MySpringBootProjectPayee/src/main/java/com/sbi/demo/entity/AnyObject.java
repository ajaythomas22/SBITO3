package com.sbi.demo.entity;

public class AnyObject {
	
	int accNum;
	
	Payee payeeObj=new Payee();
	
	public int getAccNum() {
		return accNum;
	}
	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}
	public Payee getPayeeObj() {
		return payeeObj;
	}
	public void setPayeeObj(Payee payeeObj) {
		this.payeeObj = payeeObj;
	}
	
	

}
