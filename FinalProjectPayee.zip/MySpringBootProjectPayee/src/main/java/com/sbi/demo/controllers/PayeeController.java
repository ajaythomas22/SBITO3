package com.sbi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sbi.demo.entity.*;
import com.sbi.demo.services.*;


@RestController
@RequestMapping("/payees")
public class PayeeController {

	@Autowired
    PayeeService payeeService;
	
	
	@RequestMapping("/")
	public List<Payee> allPayees()
	{
		return payeeService.findAllPayeesService();
	}
	
	@RequestMapping("/{pid}")
	public Payee getSingleAcct(@PathVariable("pid") int x)
	{
		return payeeService.findPayeeByIdService(x);
	}
	
//	@PostMapping("/addPayee")
//	public void insertPayee(@RequestBody Payee payee)
//	{
//		payeeService.insertPayeeService(payee);
//	}
	
	//@PutMapping("/updatePayee")
//	public void updatePayee(@RequestBody Payee payee)
//	{
//		payeeService.updatePayeeService(payee);
//	}
//	
//	@DeleteMapping("/deletePayee/{x}")
//	public void deletePayee(@PathVariable("x") int payeeIdToBeDeleted)
//	{
//		payeeService.deletePayeeService(payeeIdToBeDeleted);
//	}
	
}
