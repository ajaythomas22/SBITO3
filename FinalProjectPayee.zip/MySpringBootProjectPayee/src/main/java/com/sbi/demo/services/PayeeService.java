package com.sbi.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Payee;

@Service
public interface PayeeService {

	List<Payee> findAllPayeesService();
	 Payee findPayeeByIdService(int payeeId);
	 void insertPayeeService(Payee payee);
	 void updatePayeeService(Payee payee);
	 void deletePayeeService(int payeeId);
}
