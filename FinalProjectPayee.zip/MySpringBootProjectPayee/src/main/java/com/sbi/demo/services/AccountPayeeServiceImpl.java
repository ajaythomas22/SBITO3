package com.sbi.demo.services;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.*;
import com.sbi.demo.repositories.AccountRepository;
import com.sbi.demo.repositories.PayeeRepository;

@Service
public class AccountPayeeServiceImpl implements AccountPayeeService {
	
	
	@Autowired
	AccountRepository acctReps;
	
	@Autowired
	PayeeRepository payeeReps;
	
	
	@Override
	public List<Payee> viewPayeesOfThisAccountNUmber(int acno) {
		
		Account acct =acctReps.findAccountById(acno);
		List<Payee> payeeList=acct.getPayeeList();
		return payeeList;
	}

	

	@Override
	public void insertPayeeIntoThisAccountNumber(int acno, Payee payee) {
		Account acct =acctReps.findAccountById(acno);
		payee.setAccount(acct); //fillup the fK
		
	List<Payee> payeeList=acct.getPayeeList();
//		for (Payee payee2 : payeeList) {
//			if(payee2.getPayeeAcctNo()==payee.getPayeeAcctNo()) {
//				
//			}
//		}
		payeeList.add(payee);
		
		acct.setPayeeList(payeeList);
		
		acctReps.updateAccount(acct);
		
	}
	
	public void upgradeTransferLimitOfAPayee(int acno, int payeeid, int newLimit) {
		Account acct =acctReps.findAccountById(acno);
		List<Payee> payeeList=acct.getPayeeList();
		
		for (Payee payee : payeeList) {
			if(payee.getPayeeId()== payeeid) {
				payee.setPayeeLimit(newLimit);
				break;
			}
		}
		acct.setPayeeList(payeeList);
		acctReps.updateAccount(acct);
		
	}

	
	@Override
	public void deletePayeeOfThisAccountNumber(int acno, int payeeid) {
		
		
		Account acct =acctReps.findAccountById(acno);
	    List<Payee> payeeList = acct.getPayeeList();
		
		System.out.println("BEFORE SIZE "+payeeList.size());
		
		Iterator<Payee> payeeIterator = payeeList.iterator();
		while(payeeIterator.hasNext()) {
			Payee payee = (Payee) payeeIterator.next();
			if(payee.getPayeeId() == payeeid) {
				System.out.println("payee found : "+payee.getPayeeId()+" "+payee.getPayeeName());
				payeeIterator.remove();
				break;
			}
		}
		System.out.println("AFTER SIZE "+payeeList.size());
		acct.setPayeeList(payeeList);
		acctReps.updateAccount(acct);
		
		
	
		
		//List<Payee> payeeList =acct.getPayeeList();
		//System.out.println(">> BEFORE DELETE : "+payeeList.size());
		/*for (Payee payee : payeeList) {
			
			if(payee.getPayeeId() == payeeid) {
				System.out.println("Payee ID   : "+payee.getPayeeId());
				System.out.println("Payee NAME : "+payee.getPayeeName());
				payeeList.remove(payee);
				break;
			}
		}
		System.out.println(">> AFTER DELETE : "+payeeList.size());
		
		for (Payee payee : payeeList) {
			System.out.println("Payee ID   : "+payee.getPayeeId());
			System.out.println("Payee NAME : "+payee.getPayeeName());
		}*/
		//acct.setPayeeList(payeeList);
//		acctReps.updateAccount(acct);
	}
	

}
