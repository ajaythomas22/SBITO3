package com.sbi.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootProjectPayeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootProjectPayeeApplication.class, args);
		System.out.println("Payee project started");
	}

}
