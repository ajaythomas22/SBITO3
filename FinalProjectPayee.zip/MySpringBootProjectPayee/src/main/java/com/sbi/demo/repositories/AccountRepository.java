package com.sbi.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Account;

@Repository
public interface AccountRepository {
	
	 List<Account> findAllAccounts();
	 Account findAccountById(int accno);
	 void insertAccount(Account acct);
	 void updateAccount(Account acct);
	 void deleteAccount(int accno);
	 void insertPayeeByAccountNumber(int accno);
	

}
