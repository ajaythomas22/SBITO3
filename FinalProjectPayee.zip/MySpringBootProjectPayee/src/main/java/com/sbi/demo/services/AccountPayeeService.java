package com.sbi.demo.services;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Payee;

@Service
public interface AccountPayeeService {
	
	void deletePayeeOfThisAccountNumber(int acno, int payeeid);
	void insertPayeeIntoThisAccountNumber(int acno,Payee payee);
	List<Payee> viewPayeesOfThisAccountNUmber(int acno);
	public void upgradeTransferLimitOfAPayee(int acno, int payeeid, int newLimit) ;


}
