package com.sbi.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.demo.repositories.*;
import com.sbi.demo.services.AccountPayeeService;
import com.sbi.demo.entity.*;


@SpringBootTest
class MySpringBootProjectPayeeApplicationTests {

	@Autowired
	AccountRepository acctReps;
	
	@Autowired
	PayeeRepository payeeReps;
	
	@Autowired
	AccountPayeeService  aps;
	
	
	
	@Test
	void contextLoads() {
		
		List<Payee> p=aps.viewPayeesOfThisAccountNUmber(101);
		
		for (Payee pl : p)
		{
			System.out.println("PAYEE ACCTNO : "+pl.getPayeeAcctNo());
			System.out.println("PAYEE ID : "+pl.getPayeeId());
			System.out.println("LIMIT: "+pl.getPayeeLimit());
			System.out.println("PAYEE NAME: "+pl.getPayeeName());
			System.out.println("PAYEE NICK NAME : "+pl.getPayeeNickName());
			System.out.println("----------------------------------");
		
	}
	}		
		
		

		@Test
		void contextLoads1() {
			
			Account acct=acctReps.findAccountById(101);//?????
			
			Payee payee=new Payee();
			//payee.setPayeeId(3);//auto generated value
			payee.setPayeeAcctNo(158);//from angular
			payee.setPayeeName("XYZ");//from angular
			payee.setPayeeNickName("xyz");// from angular
			payee.setPayeeLimit(10000);// from angular
			//payee.setAccount(acct);//?????
			
			aps.insertPayeeIntoThisAccountNumber(acct.getAcctNo(), payee);
			System.out.println("inserted successfully");
		}	
		
		

		@Test
		void contextLoads3() {
			
			aps.deletePayeeOfThisAccountNumber(101, 2);
			System.out.println("deleted successfully");

		}
		
		@Test
		void upgradeTransferLimitOfAPayeeTest() {
			
			
			aps.upgradeTransferLimitOfAPayee(101, 1, 200000);
			System.out.println("limit updated...");
		}
			
		
		
}


