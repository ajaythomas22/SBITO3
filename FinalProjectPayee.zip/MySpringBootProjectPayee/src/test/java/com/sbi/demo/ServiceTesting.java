package com.sbi.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.demo.entity.*;
import com.sbi.demo.services.*;


@SpringBootTest
public class ServiceTesting
{

	@Autowired
	AccountService acctService;
	
	@Test
	public void allaccountsServiceTest()
	{
	
			List<Account> acctList = acctService.findAllAccountsService();
			for (Account acct : acctList)
			{
				System.out.println("ACCTNO : "+acct.getAcctNo());
				System.out.println("ACCTNAME : "+acct.getAcctName());
				System.out.println("ACCTMAILID: "+acct.getMailId());
				System.out.println("ACCTBAL: "+acct.getAccBal());
				System.out.println("USERNAME : "+acct.getUsername());
				System.out.println("PASSWORD : "+acct.getPassword());
				System.out.println("----------------------------------");
			}
			
		}
	
	@Test
	public void accountById()
	{
		Account acct=acctService.findAccountByIdService(102);
		System.out.println("ACCTNO : "+acct.getAcctNo());
		System.out.println("ACCTNAME : "+acct.getAcctName());
		System.out.println("ACCTMAILID: "+acct.getMailId());
		System.out.println("ACCTBAL: "+acct.getAccBal());
		System.out.println("USERNAME : "+acct.getUsername());
		System.out.println("PASSWORD : "+acct.getPassword());
		System.out.println("----------------------------------");
		
	}
	
	@Test
	public void insertAccount()
	{
		Account acct=new Account();
		acct.setAccBal(25000);
		acct.setAcctName("vardhan");
		acct.setAcctNo(106);
		acct.setMailId("vardhan1@gmail.com");
		acct.setUsername("vardhan1");
		acct.setPassword("vardhan@1");
		
		acctService.insertAccountService(acct);
		
	}
	
	@Test
	public void updateAccount()
	{
	  Account acct=acctService.findAccountByIdService(106);
		acct.setAccBal(50000);
		acct.setAcctName("Sai");
		acct.setAcctNo(106);
		acct.setMailId("Sai@gmail.com");
		acct.setUsername("Sai12");
		acct.setPassword("Saiv@1");
		
		acctService.updateAccountService(acct);
		
		
	}
	
	
	@Test
	public void deleteAccount()
	{
	    acctService.deleteAccountService(106);
	}
	
	@Autowired
	PayeeService payeeService;
	
	@Test
	public void allPayeesTest()
	{
	
			List<Payee> payeeList = payeeService.findAllPayeesService();
			for (Payee p : payeeList)
			{
				System.out.println("PAYEE ACCTNO : "+p.getPayeeAcctNo());
				System.out.println("PAYEE ID : "+p.getPayeeId());
				System.out.println("LIMIT: "+p.getPayeeLimit());
				System.out.println("PAYEE NAME: "+p.getPayeeName());
				System.out.println("PAYEE NICK NAME : "+p.getPayeeNickName());
				System.out.println("USER ACCOUNT : "+p.getAccount().getAcctNo());
				System.out.println("----------------------------------");
			
		}
	}			
	
	@Test
	public void PayeeById()
	{
		Payee p=payeeService.findPayeeByIdService(4);
		System.out.println("PAYEE ACCTNO : "+p.getPayeeAcctNo());
		System.out.println("PAYEE ID : "+p.getPayeeId());
		System.out.println("LIMIT: "+p.getPayeeLimit());
		System.out.println("PAYEE NAME: "+p.getPayeeName());
		System.out.println("PAYEE NICK NAME : "+p.getPayeeNickName());
		System.out.println("USER ACCOUNT : "+p.getAccount().getAcctNo());
		System.out.println("----------------------------------");
		
	}
	
	@Test
	public void insertPayee()
	{  
		Account a=acctService.findAccountByIdService(101);
		Payee p=new Payee();
		p.setPayeeId(5);
		p.setPayeeAcctNo(104);
		p.setPayeeLimit(50000);
		p.setPayeeName("Vardhan");
		p.setPayeeNickName("Hubby");
		p.setAccount(a);
		
		payeeService.insertPayeeService(p);
		
	}	
		
	
	
	@Test
	public void updatePayee()
	{
		Payee p=new Payee();
		Account a=acctService.findAccountByIdService(101);
		p.setPayeeId(5);
		p.setPayeeAcctNo(104);
	    p.setPayeeLimit(100000);
	    p.setPayeeNickName("Baby");
	    p.setPayeeName("Vardhan");
		p.setAccount(a);
		
       payeeService.updatePayeeService(p);;
		
		
	}
	
	
	@Test
	public void deletePayeeTest()
	{
	    payeeService.deletePayeeService(5);
	}
	
}
