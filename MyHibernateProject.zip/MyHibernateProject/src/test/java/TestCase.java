import java.util.List;

import org.junit.jupiter.api.Test;

import onetomany.Customer;
import onetomany.DepartmentDAO;
import onetomany.DepartmentDAOImpl;
import onetomany.Employee;
import onetomany.EmployeeDAO;
import onetomany.EmployeeDAOImpl;

public class TestCase {

	EmployeeDAO empDAO = new EmployeeDAOImpl();
	DepartmentDAO deptDAO = new DepartmentDAOImpl();

	@Test
	public void loadAllDepartmentsTest() {

		List<Employee> empList = empDAO.findAllEmployees();

		for (Employee employee : empList) {

			System.out.println(employee.getEmployeeName() + " " + employee.getEmployeeNumber() + " "
					+ employee.getDepartment()+ " " +employee.getJob());
			System.out.println("=======================================");

			List<Customer> custList= employee.getCustomerList();

			for (Customer c : custList) {

				System.out.println("Customer ID : " +c.getCustomerId());
				System.out.println("Customer Name   : " + c.getCustName());
				System.out.println("------------------------");
			}
		}
	}
}
