import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import onetoone.Passport;
import onetoone.Person;

public class TestOneToOne {

	@Test
	public void testPersonInsert() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();

		Person personObj = new Person();
		Passport passportObj = new Passport();

		et.begin();
		personObj.setPersonId(2);
		personObj.setAge(28);
		personObj.setGender('f');
		personObj.setName("Julie");

		passportObj.setPassportNumber("T-789456123");
		passportObj.setPassportIssuedDate(LocalDate.now());
		passportObj.setPassportExpiredDate(LocalDate.of(2031, 05, 10));
		passportObj.setPassportIssuedBy("Govt. of India");
		passportObj.setNationality("India");

		
		personObj.setPassport(passportObj); 
		passportObj.setPerson(personObj);
		 

		System.out.println("Trying to persist");
		em.persist(personObj);
		em.persist(passportObj);
		System.out.println("Persisted");
		et.commit();

	}
	
	@Test
	public void addPassportWithoutPerson() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		Passport passport = new Passport();
		passport.setPassportNumber("T-623623623");
		passport.setPassportIssuedDate(LocalDate.now());
		passport.setPassportExpiredDate(LocalDate.of(2032,05,10));
		passport.setPassportIssuedBy("Govt. Of India");
		passport.setNationality("Indian");

		em.persist(passport);
		et.commit();
	}

	@Test 
	public void assignExistingPassportToExistingPerson()
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();

		et.begin();
			Person person = em.find(Person.class, 2);
			Passport passport = em.find(Passport.class, "T-623623623");
			passport.setPerson(person); //fill up the foreign key person_id
			em.merge(passport);
		et.commit();
	}
}
