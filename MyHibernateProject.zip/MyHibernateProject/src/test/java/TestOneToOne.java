import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import onetoone.Passport;
import onetoone.Person;

public class TestOneToOne {

	@Test
	public void testPersonInsert() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();

		Person personObj = new Person();
		Passport passportObj = new Passport();

		et.begin();
		personObj.setPersonId(1);
		personObj.setAge(22);
		personObj.setGender('M');
		personObj.setName("Jack");

		passportObj.setPassportNumber("T-123456789");
		passportObj.setPassportIssuedDate(LocalDate.now());
		passportObj.setPassportExpiredDate(LocalDate.of(2031, 05, 10));
		passportObj.setPassportIssuedBy("Govt. of India");
		passportObj.setNationality("India");

		
		personObj.setPassport(passportObj); 
		passportObj.setPerson(personObj);
		 

		System.out.println("Trying to persist");
		em.persist(personObj);
		em.persist(passportObj);
		System.out.println("Persisted");
		et.commit();

	}
}
