import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestDAO {
	
FlightDAO flightDao = new FlightDAOImpl();
	
	@Test
	public void testSelectDAO() {
		
		Flight f = flightDao.findFlightById(1);
		Assertions.assertTrue(f!=null);
		
		System.out.println("Flight number : "+f.getFlightNumber());
		System.out.println("Flight name   : "+f.getFlightName());
		System.out.println("Flight source : "+f.getFlightSource());
		System.out.println("Flight dest   : "+f.getFlightDestination());
		System.out.println("Flight arrtime: "+f.getFlightArrivalAtDestination());
		System.out.println("Flight deptime: "+f.getFlightDepartureFromSource());
		System.out.println("Flight nop    : "+f.getNumberOfPassengers());
		System.out.println("Flight cost   : "+f.getFlightTicketCost());
	
	}
	
	@Test
	public void testSelectAllDAO() {
		List<Flight> f = flightDao.findAllFlights();
				
		for (Flight f1 : f) {
			System.out.println("Flight number : "+f1.getFlightNumber());
			System.out.println("Flight name   : "+f1.getFlightName());
			System.out.println("Flight source : "+f1.getFlightSource());
			System.out.println("Flight dest   : "+f1.getFlightDestination());
			System.out.println("Flight arrtime: "+f1.getFlightArrivalAtDestination());
			System.out.println("Flight deptime: "+f1.getFlightDepartureFromSource());
			System.out.println("Flight nop    : "+f1.getNumberOfPassengers());
			System.out.println("Flight cost   : "+f1.getFlightTicketCost());
		}
	}
	
	@Test
	public void testUpdateDAO() {
		
		Flight f1 = flightDao.findFlightById(29);
		f1.setFlightName("AirIndia");
		f1.setFlightTicketCost(4500);
		flightDao.updateFlight(f1);
		
	}
	
	@Test
	public void testDeleteDAO() {
		flightDao.deleteFlight(35);
	}
	
	@Test
	public void testSaveDAO() {
		
		Flight f = new Flight();
		
		//f.setFlightNumber(50);
		f.setFlightName("Indigo");
		f.setFlightSource("Cochin");
		f.setFlightDestination("Mumbai");
		f.setFlightArrivalAtDestination(LocalDateTime.now());
		f.setFlightDepartureFromSource(LocalDateTime.now());
		f.setNumberOfPassengers(500);
		f.setFlightTicketCost(5000);
		flightDao.saveFlight(f);
	}
	

}
