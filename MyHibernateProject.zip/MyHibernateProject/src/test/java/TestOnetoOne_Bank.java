import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import onetoone.BankApplicant;
import onetoone.PanCard;

public class TestOnetoOne_Bank {
	
	@Test
	public void testBankApplicantInsert() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();

		BankApplicant bankObj = new BankApplicant();
		PanCard panObj = new PanCard();

		et.begin();
		bankObj.setApplicantNumber(1);
		bankObj.setApplicantName("Anand");
		bankObj.setEmailAddress("anand@gmail.com");
		bankObj.setMobile("9567103471");
		bankObj.setAppliedFor("Savings A/C");
		bankObj.setApplicationStatus("Applied");
		bankObj.setAddress("Trivandrum");
		bankObj.setBirthdate(LocalDate.of(1990, 8, 22));
		
		panObj.setPanID("AKCPT4943M");
		panObj.setFathersName("Jayakumart");
		panObj.setDateOfBirth(LocalDate.of(1990, 8, 22));

		bankObj.setPanCard(panObj); 
		panObj.setBankApplicant(bankObj);
		 

		System.out.println("Trying to persist");
		em.persist(bankObj);
		em.persist(panObj);
		System.out.println("Persisted");
		et.commit();

	}
	
//	@Test
//	public void addPassportWithoutPerson() {
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
//		System.out.println("EntityManagerFactory: " + emf);
//		EntityManager em = emf.createEntityManager();
//		System.out.println("EntityManager: " + em);
//		EntityTransaction et = em.getTransaction();
//		
//		et.begin();
//		Passport passport = new Passport();
//		passport.setPassportNumber("T-623623623");
//		passport.setPassportIssuedDate(LocalDate.now());
//		passport.setPassportExpiredDate(LocalDate.of(2032,05,10));
//		passport.setPassportIssuedBy("Govt. Of India");
//		passport.setNationality("Indian");
//
//		em.persist(passport);
//		et.commit();
//	}
//
//	@Test 
//	public void assignExistingPassportToExistingPerson()
//	{
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
//		System.out.println("EntityManagerFactory: " + emf);
//		EntityManager em = emf.createEntityManager();
//		System.out.println("EntityManager: " + em);
//		EntityTransaction et = em.getTransaction();
//
//		et.begin();
//			Person person = em.find(Person.class, 2);
//			Passport passport = em.find(Passport.class, "T-623623623");
//			passport.setPerson(person); //fill up the foreign key person_id
//			em.merge(passport);
//		et.commit();
//	}
//	
}
