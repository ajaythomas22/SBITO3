import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import onetoone.BankApplicant;
import onetoone.PanCard;

public class TestOnetoOne_Bank {
	
	@Test
	public void testBankApplicantInsert() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory: " + emf);
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager: " + em);
		EntityTransaction et = em.getTransaction();

		BankApplicant bankObj = new BankApplicant();
		PanCard panObj = new PanCard();

		
		bankObj.setApplicantNumber(2);
		bankObj.setApplicantName("Sruthi");
		bankObj.setEmailAddress("sruthi@gmail.com");
		bankObj.setMobile("987654321");
		bankObj.setAppliedFor("Fixed Deposit A/C");
		bankObj.setApplicationStatus("Applied");
		bankObj.setAddress("Thrissur");
		bankObj.setBirthdate(LocalDate.of(1990, 8, 22));
		
		panObj.setPanID("QWERT2345Y");
		panObj.setFathersName("Nair");
		panObj.setDateOfBirth(LocalDate.of(1990, 8, 22));

		bankObj.setPanCard(panObj); 
		panObj.setBankApplicant(bankObj);
		 
		et.begin();
		System.out.println("Trying to persist");
		em.persist(bankObj);
		em.persist(panObj);
		System.out.println("Persisted");
		et.commit();

	}
	
	@Test
 	public void addPanWithoutBank_Applicant() {
 		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
 		System.out.println("EntityManagerFactory: " + emf);
 		EntityManager em = emf.createEntityManager();
 		System.out.println("EntityManager: " + em);
 		EntityTransaction et = em.getTransaction();
 		
 		
 		PanCard panObj = new PanCard();
 		panObj.setPanID("ASDFG7894H");
 		panObj.setPanName("Sruthi");
  		panObj.setFathersName("Nair");
 		panObj.setDateOfBirth(LocalDate.of(1992, 10, 8));
 
 		et.begin();
 		em.persist(panObj);
 		et.commit();
 	}
 
 	@Test 
 	public void assignExistingPanToBankApplicant()
 	{
 		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
 		System.out.println("EntityManagerFactory: " + emf);
 		EntityManager em = emf.createEntityManager();
 		System.out.println("EntityManager: " + em);
 		EntityTransaction et = em.getTransaction();
 
 		
 			BankApplicant bankObj = em.find(BankApplicant.class, 2);
 			PanCard panObj = em.find(PanCard.class, "ASDFG7894H");
 			panObj.setBankApplicant(bankObj);  //fill up the foreign key person_id
 		et.begin();
 			em.merge(panObj);
 		et.commit();
 	}
 	
}
