import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.internal.build.AllowSysOut;

public class CrudTest {

	public static void main(String[] args) {
		System.out.println("Trying to read persistence.xml file...");
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");
		
		EntityManager em = emf.createEntityManager();
		System.out.println("EntityManager created....");
		
		EntityTransaction et = em.getTransaction();
		System.out.println("EntityTransaction created....");
		
		System.out.println("Trying to create record.....");
//		Flight theFlight= new Flight();
//		//theFlight.setFlightNumber(103);
//		theFlight.setFlightName("Air Asia");
//		theFlight.setFlightSource("Bangalore");
//		theFlight.setFlightDestination("USA");
//		theFlight.setFlightTicketCost(100500);
//		theFlight.setNumberOfPassengers(400);
//		theFlight.setFlightDepartureFromSource(LocalDateTime.now());
//		theFlight.setFlightArrivalAtDestination(LocalDateTime.now());
//		
//		S E L E C T
//		et.begin();
//			em.persist(theFlight);
//		et.commit();
//		System.out.println("=================");
		
		
//		U P D A T E 
//		et.begin();
//			Flight f1 = em.find(Flight.class, 30);
//			f1.setFlightSource("Navi Mumbai");
//			em.merge(f1);
//		et.commit();
		
//		D E L E T E
//		et.begin();
//			Flight f2 = em.find(Flight.class, 30);
//			em.remove(f2);
//		et.commit();
		
//		S E L E C T "ONE" R E C O R D
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter the Flight Number to be enquired: ");
//		int flno=scan.nextInt();
//		Flight f3 = em.find(Flight.class, flno);
//		System.out.println("Flight Number: " +f3.getFlightNumber());


		
		Query q = em.createNativeQuery("Select * from flight_info", Flight.class);
		List<Flight> f4 = (List<Flight>) q.getResultList();
		
//		Query q = em.createQuery("from Flight");
//		List<Flight> f4 = q.getResultList();
		
		for(Flight list : f4) {
			
			System.out.println("\nFlight Number is: "+list.getFlightNumber());
			System.out.println("Flight Name: " +list.getFlightName());
			System.out.println("Flight Source: "+list.getFlightSource());
			System.out.println("Flight Destination: "+list.getFlightDestination());
			System.out.println("Flight Cost: "+list.getFlightTicketCost());
			System.out.println("No. of Passengers: "+list.getNumberOfPassengers());
			System.out.println("----------------------------------------");
		}
		
		System.out.println("Created the record.....");
		
	}

}