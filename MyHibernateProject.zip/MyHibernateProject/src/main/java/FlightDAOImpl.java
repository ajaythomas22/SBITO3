import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FlightDAOImpl implements FlightDAO {

	EntityManager entityMan;
	
	public FlightDAOImpl () {
		EntityManagerFactory entityManFact = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManager: " +entityMan);
		this.entityMan= entityManFact.createEntityManager();
		System.out.println("EntityManager: "+entityMan);
	}

	@Override
	public List<Flight> findAllFlights() {
		Query q = entityMan.createQuery("from Flight");
		return q.getResultList();
	}

	@Override
	public Flight findFlightById(int flno) {
		return entityMan.find(Flight.class, flno);
	}

	@Override
	public void saveFlight(Flight flight) {
		EntityTransaction et = entityMan.getTransaction();
		et.begin();
		entityMan.persist(flight);
		et.commit();

	}

	@Override
	public void updateFlight(Flight flight) {
		EntityTransaction et = entityMan.getTransaction();
		et.begin();
		entityMan.merge(flight);
		et.commit();
		
	}

	@Override
	public void deleteFlight(int flno) {
		EntityTransaction et = entityMan.getTransaction();
		et.begin();
		Flight f = entityMan.find(Flight.class, flno);
		entityMan.remove(f);
		et.commit();
		
	}

}
