package onetomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	@Column(name="CUSTID",length=6)
	private String customerId;
	
	@Column(name="NAME",length=45)
	private String custName;
	
	@Column(name="ADDRESS",length=40)
	private String custAddress;
	
	@Column(name="CITY",length=30)
	private String custCity;
	
	@Column(name="STATE",length=2)
	private String custState;
	
	@Column(name="ZIP",length=9)
	private String custZip;
	
	@Column(name="AREA",length=3)
	private Integer custArea;
	
	@Column(name="PHONE",length=9)
	private String custPhone;
	
	@ManyToOne
	@JoinColumn(name="REPID")
	private Employee employee;
	
	@Column(name="CREDITLIMIT")
	private Double creditLimit;
	
	@Column(name="COMMENTS")
	private Long comments;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getCustCity() {
		return custCity;
	}

	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}

	public String getCustState() {
		return custState;
	}

	public void setCustState(String custState) {
		this.custState = custState;
	}

	public String getCustZip() {
		return custZip;
	}

	public void setCustZip(String custZip) {
		this.custZip = custZip;
	}

	public Integer getCustArea() {
		return custArea;
	}

	public void setCustArea(Integer custArea) {
		this.custArea = custArea;
	}

	public String getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(Double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public Long getComments() {
		return comments;
	}

	public void setComments(Long comments) {
		this.comments = comments;
	}
	
	
	
	
}
