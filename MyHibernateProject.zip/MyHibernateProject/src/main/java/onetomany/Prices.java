package onetomany;

public class Prices {

}
