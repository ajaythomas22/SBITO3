package onetomany;

import java.util.List;

public interface EmployeeDAO {
	
	void changeDepartmentOfSpecificEmployees(int oldDeptNo, int newDeptNo);
	List<Employee> findAllEmployees();	

}
